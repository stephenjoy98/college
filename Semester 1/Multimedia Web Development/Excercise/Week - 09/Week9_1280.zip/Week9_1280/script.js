//Define a function
function myFunc() {
    var fname = "Anu";
    console.log(fname);
    console.log(i);
    {
        let i = 9;
        console.log("Inside the function and the block", i)
    }
    console.log(i)
}

var i = 10;
console.log(i);

//invoking or calling the function
myFunc();
//console.log(fname);

//Block Scoped - let
{
    const x = 20;
    //x = 30;
    console.log("inside the block", x);
}
console.log(x);

// var  --> function scope
// let --> block scope
// const --> block scope




