let arr = [10, 34.6, "red"];
let para = document.getElementById("para");
console.log("The array is: ", arr);
console.log("The array has length: ", arr.length);


/* for (let i = 0; i < arr.length; i++) {
    para.innerHTML += arr[i] + "<br>";
} */

//for-of loop - iterates through the values
for (let value of arr) {
    para.innerHTML += value + "<br>";
}
//for-in loop - iterates through the properties of the object
//for-in should not be used with array
/* for (let i in arr) {
    para.innerHTML += arr[i] + "<br>";
}
 */


let arr2 = [];
console.log("The array is: ", arr2);

//Another way to create an array in JavaScript

let arr3 = new Array();
console.log("The array is: ", arr3);

let arr4 = ["apple", "orange"];
let arr5 = new Array("apple, orange");

console.log("The array is: ", arr4);
console.log("The array is: ", arr5);

//Note the difference in the fololwing two arrays:
let arr6 = new Array(5);  //length 5
arr6[3] = "color";
console.log("The array is: ", arr6);

let arr7 = [5];         //length 1
arr7[4] = "element";
console.log("The array is: ", arr7);

