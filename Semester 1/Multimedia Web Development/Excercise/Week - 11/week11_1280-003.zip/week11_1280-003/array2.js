let para = document.getElementById("para");

//create an array
let arr = ["purple", 33, 44.5, "car", "apple", 45];

//Displaying the array
console.log("The array is: ", arr);
displayArray();


//Sorting the array
arr.sort();
//Displaying the sorted array
displayArray();

//Reversing the array
arr.reverse();
//Displaying the reversed array
displayArray();

//splice and slice methods
//arr.splice(2, 3, "new1", 78, "strawberry", "music");
let remArr = arr.splice(2, 3, "new1", 78, "strawberry", "music");
//arr.splice(2, 3);
displayArray();
console.log(remArr);

let remArr2 = arr.slice(2, 6);
displayArray();
console.log("The slice is: ", remArr2);

function displayArray() {
    para.innerHTML += "<hr>";
    for (let element of arr) {
        para.innerHTML += element + "<br>";
    }
}

//push() and unshift()

arr.push("Guitar");
arr.unshift("basketball");
displayArray();

//pop() and shift()

let element1 = arr.pop();   //removes the element from the end
let element2 = arr.shift(); //removes the element from the beginning

console.log("The removed element is: ", element1);
console.log("The removed element is: ", element2);
//Displaying the array
displayArray();

//join() operation

//let string = arr.join();
let string = arr.join(" and ");
console.log(string);
