
let arr = [];
let para = document.getElementById("para");

function add() {
    let value = document.getElementById("arrayElement").value;
    //console.log(value);
    arr.push(value);
    document.getElementById("arrayElement").value = "";

}
function display() {
    para.innerHTML = "";
    for (let i = 0; i < arr.length; i++)
        para.innerHTML += "Element " + i + " = " + arr[i] + "<br>";
    para.style.color = "#005500";
    para.style.border = "2px dotted black";
    para.style.fontStyle = "italic";
    para.style.fontWeight = "bold";
}