let arrMovies = ["Aliens", "harry Potter", " SpiderMan", "Birds of Prey", "Ex Machina", "Gladiator", "Vengers"];

let display = document.getElementById("mMovies");

let min = 0, max = arrMovies.length;

function displayMovies() {

    //Generating three random numbers
    let random1, random2, random3;
    do {
        random1 = Math.floor(Math.random() * max);
        random2 = Math.floor(Math.random() * max);
        random3 = Math.floor(Math.random() * max);
    } while (random1 == random2 || random1 == random3 || random2 == random3)

    console.log(random1, random2, random3);

    //Displaying three randome movies
    display.innerHTML = arrMovies[random1] + "<br>";
    display.innerHTML += arrMovies[random2] + "<br>";
    display.innerHTML += arrMovies[random3] + "<br>";
}

function resetValues() {
    display.innerHTML = "";
}
function updateMovies() {
    display.innerHTML = "";
    //get the value that ahs been entered by user
    let userEntry = document.getElementById("myMovie").value;
    document.getElementById("myMovie").value = "";
    console.log(userEntry);
    if (userEntry == "") {
        alert("The movie name can't be blank");
    }
    else {
        arrMovies.push(userEntry);
        for (let movie of arrMovies) {
            display.innerHTML += movie + "<br>"
        }
    }
}



