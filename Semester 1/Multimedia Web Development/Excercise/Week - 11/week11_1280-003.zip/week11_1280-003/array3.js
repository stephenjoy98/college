let arr = [4, 6, 8, 1, 3, 9, 5, 2];
//find sum, average of the elemnts of the array
//find the minimum and the maximum element in the array

let min, max;
min = arr[0];
max = arr[0];

for (let i = 0; i < arr.length; i++) {
    //finding the minimum
    if (arr[i] < min) {
        min = arr[i];
    }

    //finding the maximum
    if (arr[i] > max) {
        max = arr[i];
    }
}
console.log("the minimum is: ", min)
console.log("the maximum is: ", max)