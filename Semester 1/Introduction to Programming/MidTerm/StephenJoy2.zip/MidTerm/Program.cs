﻿/*
 * Name         : Stephen Joy
 * Student ID   : 300329148
 */

using System;
using static System.Console;

namespace MidTerm
{
    class Program
    {
        static void Main(string[] args)
        {
            float workHours, hourlyRate;
            double calculatedGrossPayment;
            const float overTimeLimit = 40f;
            const float taxRate = 0.09f;

            workHours = GetUserInput("number of work hours in this week");

            if (workHours > 0)
            {
                hourlyRate = GetUserInput("hourly rate");

                if (hourlyRate > 0)
                {
                    calculatedGrossPayment = GrossPayment(workHours, hourlyRate, overTimeLimit);
                    Write("\n\n\n");
                    Write("\t Employee Pay Slip");
                    Write("\n \"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"");
                }
                else
                {
                    Write("Enter a value greater than 0!");
                }
            }
            else
            {
                Write("Enter a value greater than 0!");
            }

            ReadKey();
        }

        static float GetUserInput(string text)
        {
            string userValue;
            float inputValue;
            bool isValid;

            Write($"Enter {text}: ");
            userValue = ReadLine();
            isValid = float.TryParse(userValue, out inputValue);

            if (!isValid)
            {
                Write("Enter a numeric value!\n");
                inputValue = 0f;
                return inputValue;
            }
            else
            {
                if (inputValue < 0)
                {
                    Write("Enter a positive numeric value!\n");
                    inputValue = 0f;
                    return inputValue;
                }
                else
                {
                    return inputValue;
                }
            }
        }

        static double GrossPayment(float workHours, float hourlyRate, float overTimeLimit)
        {
            double grossPay=0;

            if (workHours <= 40)
            {
                grossPay = workHours * hourlyRate;
                return grossPay;
            }
            else if ((workHours > 40)&&(workHours < 50))
            {
                grossPay = ((workHours - overTimeLimit) * hourlyRate * 1.5) + (overTimeLimit * hourlyRate);
                return grossPay;
            }
            else if ((workHours >= 50) && (workHours < 60))
            {
                grossPay = ((workHours - overTimeLimit) * hourlyRate * 2) + (overTimeLimit * hourlyRate);
                return grossPay;
            }
        }

        static void DisplayOutput(string text, double value)
        {
            Write($"{text,-15}{value,-9:C}");
        }
    }
}
