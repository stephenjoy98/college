﻿using System;
using static System.Console;

namespace MidTerm
{
    class Program
    {
        static void Main(string[] args)
        {
            float workHours, hourlyRate;
            double calculatedGrossPayment;

            workHours = GetUserInput("number of work hours in this week");

            if (workHours > 0)
            {
                hourlyRate = GetUserInput("hourly rate");

                if (hourlyRate > 0)
                {
                    calculatedGrossPayment = 
                }
            }

            ReadKey();
        }

        static float GetUserInput(string text)
        {
            string userValue;
            float inputValue;
            bool isValid;

            Write($"Enter {text}: ");
            userValue = ReadLine();
            isValid = float.TryParse(userValue, out inputValue);

            if (!isValid)
            {
                WriteLine("Enter a numeric value!");
                inputValue = 0f;
                return inputValue;
            }
            else
            {
                if (inputValue < 0)
                {
                    WriteLine("Enter a positive numeric value!");
                    inputValue = 0f;
                    return inputValue;
                }
                else
                {
                    return inputValue;
                }
            }
        }
    }
}
