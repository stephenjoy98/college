/*
 * Programmer: Saeed Mirjalili
 * Fall 2019
 */

using System;
using static System.Console;

namespace drawShapes
{
    class Program
    {
        static void Main(string[] args)
        {
            string shapesString;
            const string ALLOWED_CHARACTERS = "EHLNTXZ";
            int dimension;

            // setting Console title
            Title = "Assignment 5 - Saeed Mirjalili";

            // GetUserString gets as input the ALLOWED_CHARACTERS and returns a valid string entered by the user
            shapesString = GetUserString(ALLOWED_CHARACTERS);

            // GetUserInput gets a string to be shown to the user and it returns an odd interger greater than 3 entered by the user 
            dimension = GetUserInput("an odd number greater than 2 for the dimension of the shape: ");

            for (int i = 0; i < shapesString.Length; i++)
            {
                // ToUpper converts an alphabet letter to uppercase. If the letter is already uppercase, ToUpper does not change it.
                switch (char.ToUpper(shapesString[i]))
                {
                    case 'E':
                        DrawE(dimension);
                        break;
                    case 'H':
                        DrawH(dimension);
                        break;
                    case 'L':
                        DrawL(dimension);
                        break;
                    case 'N':
                        DrawN(dimension);
                        break;
                    case 'T':
                        DrawT(dimension);
                        break;
                    case 'X':
                        DrawX(dimension);
                        break;
                    case 'Z':
                        DrawZ(dimension);
                        break;
                    default:
                        WriteLine(shapesString[i] + " is not supported!");
                        break;
                }
            }
            Write("Press a key to quit...");
            ReadKey();
        }
        // drawing the letter E
        private static void DrawE(int dimension)
        {
            WriteLine();
            for (int row = 1; row <= dimension; row++)
            {
                for (int col = 1; col <= dimension; col++)
                {
                    if (row == 1 || row == dimension || row == Math.Ceiling(dimension / 2.0) || col == 1)
                    {
                        Write("*");
                    }
                    else
                    {
                        Write(" ");
                    }
                }
                WriteLine();
            }
            WriteLine();
        }
        // drawing the letter H
        private static void DrawH(int dimension)
        {
            WriteLine();
            for (int row = 1; row <= dimension; row++)
            {
                for (int col = 1; col <= dimension; col++)
                {
                    if (col == 1 || col == dimension || row == Math.Ceiling(dimension / 2.0))
                    {
                        Write("*");
                    }
                    else
                    {
                        Write(" ");
                    }
                }
                WriteLine();
            }
            WriteLine();
        }
        // drawing the letter L
        private static void DrawL(int dimension)
        {
            WriteLine();
            for (int row = 1; row <= dimension; row++)
            {
                for (int col = 1; col <= dimension; col++)
                {
                    if (col == 1 || row == dimension)
                    {
                        Write("*");
                    }
                    else
                    {
                        Write(" ");
                    }
                }
                WriteLine();
            }
            WriteLine();
        }
        // drawing the letter N
        private static void DrawN(int dimension)
        {
            WriteLine();
            for (int row = 1; row <= dimension; row++)
            {
                for (int col = 1; col <= dimension; col++)
                {
                    if (col == 1 || col == dimension || col == row)
                    {
                        Write("*");
                    }
                    else
                    {
                        Write(" ");
                    }
                }
                WriteLine();
            }
            WriteLine();
        }
        // drawing the letter T
        private static void DrawT(int dimension)
        {
            WriteLine();
            for (int row = 1; row <= dimension; row++)
            {
                for (int col = 1; col <= dimension; col++)
                {
                    if (row == 1 || col == Math.Ceiling(dimension / 2.0))
                    {
                        Write("*");
                    }
                    else
                    {
                        Write(" ");
                    }
                }
                WriteLine();
            }
            WriteLine();
        }
        // drawing the letter X
        private static void DrawX(int dimension)
        {
            WriteLine();
            for (int row = 1; row <= dimension; row++)
            {
                for (int col = 1; col <= dimension; col++)
                {
                    if (col == row || row + col - 1 == dimension)
                    {
                        Write("*");
                    }
                    else
                    {
                        Write(" ");
                    }
                }
                WriteLine();
            }
            WriteLine();
        }
        // drawing the letter Z
        private static void DrawZ(int dimension)
        {
            WriteLine();
            for (int row = 1; row <= dimension; row++)
            {
                for (int col = 1; col <= dimension; col++)
                {
                    if (row == 1 || row == dimension || row + col - 1 == dimension)
                    {
                        Write("*");
                    }
                    else
                    {
                        Write(" ");
                    }
                }
                WriteLine();
            }
            WriteLine();
        }

        private static int GetUserInput(string textMessage)
        {
            bool invalidNumber;
            int userValue;
            do
            {
                invalidNumber = false;
                Write("Enter " + textMessage);
                if (!int.TryParse(ReadLine(), out userValue))
                {
                    WriteLine("Enter " + textMessage);
                    invalidNumber = true;
                }
                else if (userValue % 2 == 0)
                {
                    WriteLine(userValue + " is not odd!");
                    invalidNumber = true;
                }
                else if (userValue < 3)
                {
                    WriteLine("Must be greater than 3!");
                    invalidNumber = true;
                }
            } while (invalidNumber);

            return userValue;
        }

        private static string GetUserString(string allowedCharacters)
        {
            string userInputStr;
            string invalidChars;

            do
            {
                invalidChars = "";
                Write("Enter a string, including only the following characters ( {0} ) : ", allowedCharacters);
                userInputStr = ReadLine();
                foreach (char ch in userInputStr)
                {
                    if (allowedCharacters.IndexOf(char.ToUpper(ch)) == -1)
                    {
                        invalidChars += ch;
                    }
                }
                if (invalidChars != "")
                {
                    // this is a simple version to show the unaccepted characters
                    // WriteLine("{0} is(are) not accepted, only {1} characters are accepted! Re-enter your characters.", invalidChars, allowedCharacters);

                    // a more complex and nicer way to show unaccepted characters is to show them as a comma seperated list
                    Write(invalidChars[0]);  // displaying the first character
                    for (int i = 1; i < invalidChars.Length; i++)  // displaying the rest of the invalid characters, if any, seperated by comma
                    {
                        Write("," + invalidChars[i]);
                    }
                    if (invalidChars.Length == 1)
                    {
                        Write(" is ");
                    }
                    else
                    {
                        Write(" are ");
                    }
                    WriteLine("not accepted, only {0} characters are accepted! Re-enter your characters.", allowedCharacters);
                }
            } while (invalidChars != "");

            return userInputStr;
        }
    }
}
